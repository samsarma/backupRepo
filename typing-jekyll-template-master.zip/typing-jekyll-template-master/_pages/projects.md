---
layout: page
order: 2
title: Projects
sitemap:
  priority: 0.7
  changefreq: 'monthly'
  lastmod: 2017-05-04T12:49:30-05:00
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-briefcase
menu:
  enable: true
  local: [default]
script: []
published: true
permalink: /projects/ # add permilink for page. E.g: /smallparty/
---
 
If you wanted to know about my favorite chores, this is the correct page. You find my designs of my own, or participation.

## Major collaborations

[Typing Theme](https://github.com/williamcanin/typing-jekyll-template) : Creating themes for Jekyll


|[Typing Jekyll Template](https://github.com/williamcanin/typing-jekyll-template){:target="_blank"}|
--------------------------|----------------------------
| **Status**: <label style="color:green;">Active</label> |
| **Description**: Typing, is a template for Jekyll built especially for those who want to have a blog and pages quickly and lightly. |
