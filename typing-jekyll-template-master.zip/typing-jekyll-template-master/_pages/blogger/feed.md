---
layout: null
order: 4
title: Feed
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-rss
menu:
  enable: true
  local: [blog]
script: []
published: true
permalink: /feed.xml # add permilink for page. E.g: /smallparty/
---

<!-- Do not delete this file! -->
