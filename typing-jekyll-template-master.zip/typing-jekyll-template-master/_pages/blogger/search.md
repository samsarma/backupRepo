---
layout: search
order: 3
title: Search
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-search
menu:
  enable: true
  local: [blog]
script: [search.js]
published: true
permalink: /blog/search/ # add permilink for page. E.g: /smallparty/
---

<!-- Do not delete this file! Put your text below. -->

Type something in the field to perform a search for an article in the Blog. Good hunting!
