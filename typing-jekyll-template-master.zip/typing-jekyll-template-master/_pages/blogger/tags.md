---
layout: taglist
order: 2
title: Tags
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-tags
menu:
  enable: true
  local: [blog]
script: []
published: true
permalink: /blog/tags/ # add permilink for page. E.g: /smallparty/
---

<!-- Do not delete this file! Put your text below. -->

Here you find the option to find content through Tags. An easy way to know what kind of content there is on the Blog. Good hunting!
