---
layout: postlist
order: 1
title: Blog
posts_quantity:
  message: ['There are','posts in total.']
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-edit
menu:
  enable: true
  local: [default, blog]
pagination:
  enabled: true
script: [postlist.js]
# NOTE: If you disable blog posting, you'll have to 
#       disable tags.md, feed.md and search.md too.
published: true
permalink: /blog/ # add permilink for page. E.g: /smallparty/
---

<!-- Do not delete this file! Put your text below. -->

What follows is a list of weblog posts from as early as {{ site.debutyear }}. I hope you enjoy