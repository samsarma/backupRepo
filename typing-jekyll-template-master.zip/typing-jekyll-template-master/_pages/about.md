---
layout: page
order: 5
title: "About"
date: 2019-10-03 04:03:41 -300
sitemap:
  priority: 0.7
  changefreq: 'monthly'
  lastmod: 2019-10-03 04:03:41
# Use icons of: https://fontawesome.com/icons
# E.g: fa-briefcase
icon: fa-user
menu:
  enable: true
  local: [default]
script: []
published: true
permalink: /about/ # add permilink for page. E.g: /smallparty/
---
 
<!-- Write from here your page !!! -->

Hey, I'am [Typing](https://github.com/williamcanin/typing-jekyll-template){: target="_blank"}. I'm a theme [Jekyll](https://jekyllrb.com){: target="_blank"} Inspired by the habit of typing. Using an appearance that resembles the typewriter. A simple, fast and efficient way of reading, just like the old days.

'Typing' is intended for users with more technical content than for users who wish to have a stylish page. Keep it simple!

**Let's see some details about this page:**

This page exists to put everything about you, as if it were a simplified 'About'. The file for editing this page is in the directory root: `index.md`.

Hey Nerd! How is it? You're analyzing me, but are not you using me? Use me now! I'm not into embellishment. 

[Download](https://github.com/williamcanin/typing-jekyll-template){: target="_blank"}